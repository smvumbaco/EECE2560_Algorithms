                    cout << vectorToString(rightDiag) << endl;
